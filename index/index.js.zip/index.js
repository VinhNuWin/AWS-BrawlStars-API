'use strict'

console.log('Loading function');

var AWS = require('aws-sdk');

// Initialize the Amazon Cognito credentials provider.
AWS.config.region = "us-west-2";
AWS.config.credentials = new AWS.CognitoIdentityCredentials({
    IdentityPoolId: "us-west-2:110254dc-6362-4d82-b1da-f11699e2bc49",
});


// Create client.
const docClient = new AWS.DynamoDB.DocumentClient();


exports.handler =  async function(event, context) {
    const params = {
        FunctionName: 'myFunction',
        Item: {
            brawlerName: event.Item.brawlerName,
            Attack: event.Item.attack,
            health: event.Item.health
        },
        TableName: event.TableName
    };
    await docClient.put(params, async function (err, data) {
        if (err) {
            console.error(
                "Unable to add item. Error JSON:",
                JSON.stringify(err, null, 2)
            );
        } else {
            console.log("Adding data to dynamodb...");
            console.log("Added item:", JSON.stringify(data, null, 2));
        }
    });
    response(null, event);
};

// exports.handler = async(event, context, callback) => {
//     const brawlerName = event.pathParemeters.brawlername

//     const params = {
//         TableName: 'DesignRequests',
//         Key: { brawlerName }
//     };
//     await docClient.put(params, async function(err, data){
//         if (err) {
//             console.error(
//                 "Unable to add item. Error JSON:",
//                 JSON.stringify(err, null, 2)
//             );
//         } else {
//             console.log("Adding data to dynamodb...");
//             console.log("Added item:", JSON.stringify(data, null, 2));
//         }
//     });
//     callback(null, event);
// };